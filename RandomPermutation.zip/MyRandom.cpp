

#include "MyRandom.h"
#include <math.h>




RandDevice RandDevice::SetSeed(unsigned int seed)
{
    RandDevice d;
    d.gen = new std::mt19937(seed);
    d.rd = NULL;
    return d;
}
RandDevice RandDevice::RandomSeed()
{
    RandDevice d;
    d.rd = new std::random_device();
    d.gen = new std::mt19937(d.rd->operator()());
    return d;
}
void RandDevice::DeleteDevice(RandDevice d)
{
    if (d.gen != NULL)
    {
        delete d.gen;
        d.gen = NULL;
    }
    if (d.rd != NULL)
    {
        delete d.rd;
        d.rd = NULL;
    }
}

int UniformN(RandDevice d, int a, int b)
{
    std::uniform_int_distribution<> distrib(a, b);
    return distrib(*d.gen);
}


float UniformF(RandDevice d, float a, float b)
{
    std::uniform_real_distribution<> distrib(a, b);
    return distrib(*d.gen);
}


int TrunGeom(RandDevice d, float q, int n)
{
    float u = UniformF(d, 0, 1);

    return lround(ceil( log(1-u*(1-pow(q, n)))/log(q) ));
}