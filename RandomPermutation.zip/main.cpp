

// Animation2D.cpp : Defines the entry point for the application.
//
#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>
#include <crtdbg.h>

#include <fstream>
#include <vector>
#include <windows.h>

#include <d2d1.h>
#include <d2d1_1.h>
#include <dwrite.h>

#pragma comment(lib, "D2D1.lib")
#pragma comment(lib, "Dwrite.lib")
#pragma comment(lib, "Dxguid.lib")
#pragma comment(lib, "Windowscodecs.lib")


#include <wincodec.h>
#include <string>
#include <vector>
#include <ctime>

#include "RandPerm.h"


#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#define new DBG_NEW
#else
#define DBG_NEW new
#endif

#ifndef _UNICODE
typedef CHAR Char;
#define Text(t) (t)
#else
typedef WCHAR Char;
#define Text(t) L##t
#endif

using namespace D2D1;
using namespace std;

// Global Variables:
HINSTANCE hInst;                                // current instance
const Char *szTitle;                  // The title bar text
const Char *szWindowClass;            // the main window class name
HWND  g_hWnd;


ID2D1Factory1 *g_pFactory = NULL;
IDWriteFactory *g_pWriteFactory = NULL;
IWICImagingFactory *g_pWICImageingFactory = NULL;

IDWriteTextFormat *g_pTextFormat = NULL;


int g_nWidth = 700;
int g_nHeight = 700;

int s = 1;




// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

HRESULT             InitD2D();
void                CleanUpD2D();

HRESULT InitD2D()
{
    HRESULT hr;
    CoInitialize(NULL);
    hr = CoCreateInstance(
        CLSID_WICImagingFactory,
        NULL,
        CLSCTX_INPROC_SERVER,
        IID_IWICImagingFactory,
        (LPVOID *)&g_pWICImageingFactory
    );
    hr = D2D1CreateFactory(D2D1_FACTORY_TYPE::D2D1_FACTORY_TYPE_SINGLE_THREADED, &g_pFactory);
    if (FAILED(hr))
        return hr;

    hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE::DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), (IUnknown **)&g_pWriteFactory);
    hr = g_pWriteFactory->CreateTextFormat(L"Microsoft Sans Serif", NULL, DWRITE_FONT_WEIGHT_NORMAL, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL, 20, L"", &g_pTextFormat);
    g_pTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);

    g_pTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);


    return hr;
}
void CleanUpD2D()
{
    if (g_pFactory != NULL)
    {
        g_pFactory->Release();
        g_pFactory = NULL;
    }
    if (g_pTextFormat != NULL)
    {
        g_pTextFormat->Release();
        g_pTextFormat = NULL;
    }
    if (g_pWriteFactory != NULL)
    {
        g_pWriteFactory->Release();
        g_pWriteFactory = NULL;
    }
    if (g_pWICImageingFactory != NULL)
    {
        g_pWICImageingFactory->Release();
        g_pWICImageingFactory = NULL;
    }

    CoUninitialize();
}

void Refresh(HWND hWnd)
{
    RECT rect;
    GetClientRect(hWnd, &rect);
    InvalidateRect(hWnd, &rect, TRUE);
    UpdateWindow(hWnd);
}

bool g_IsDown = false;

int g_nX = 0;
int g_nY = 0;


MonoPermData monotoneRestricion;


int N;
int MSize;
unsigned int *Perm;
RandDevice device;

int SliderBorder = 30;
int SliderHeight = 30;
bool isOnSlider = 0;
int SliderR = 6;
float q = 0.9;

void InitPerm()
{
    monotoneRestricion.dim = 4;
    monotoneRestricion.X = new unsigned int[4];
    monotoneRestricion.Y = new unsigned int[4];
    monotoneRestricion.X[0] = 1;
    monotoneRestricion.X[1] = 2;
    monotoneRestricion.X[2] = 3;
    monotoneRestricion.X[3] = 4;
    monotoneRestricion.Y[0] = 4;
    monotoneRestricion.Y[1] = 3;
    monotoneRestricion.Y[2] = 2;
    monotoneRestricion.Y[3] = 1;
    MSize = 10;
    N = 100;

    Perm = new unsigned int[N* MSize];

    for (int i = 0; i < N*MSize; i++)
        Perm[i] = 0;

    device = RandDevice::SetSeed(1798297);
}
void Resample()
{
    MonotoneSampling(monotoneRestricion, N, q, Perm, device);
}
void CleanupPerm()
{
    delete[] monotoneRestricion.X;
    delete[] monotoneRestricion.Y;
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int xPos = (lParam & 0x0000FFFF);
    int yPos = (lParam >> 16);
    switch (message)
    {
    case WM_ERASEBKGND:
    {
        ID2D1HwndRenderTarget *pRenderTarget = NULL;
        HRESULT hr = g_pFactory->CreateHwndRenderTarget(D2D1::RenderTargetProperties(), D2D1::HwndRenderTargetProperties(g_hWnd, SizeU(g_nWidth, g_nHeight)), &pRenderTarget);

        pRenderTarget->BeginDraw();
        pRenderTarget->Clear(ColorF(ColorF::White));

        ID2D1SolidColorBrush *pBrush;

        pRenderTarget->CreateSolidColorBrush(ColorF(ColorF::Red), &pBrush);


        int pRSum = 0;
        int pCSum = 0;
        float p = 1.0f / (MSize);
        for (int i = 0; i < monotoneRestricion.dim; i++)
        {
            float l = ((float)pRSum) * p;
            float r = ((float)pRSum+monotoneRestricion.X[i]) * p;
            float t = ((float)pCSum+monotoneRestricion.Y[i]) * p;
            float b = 1;

            pRSum += monotoneRestricion.X[i];
            pCSum += monotoneRestricion.Y[i];

            pRenderTarget->FillRectangle(RectF(l * g_nWidth / s, t * g_nHeight / s, r * g_nWidth / s, b * g_nHeight / s), pBrush);
        }

        pBrush->SetColor(ColorF(ColorF::Black));

        p = 1.0f / (MSize * N);
        float pad = 1;
        for (int i = 0; i < MSize * N; i++)
        {
            float l = ((float)i) * p;
            float r = ((float)i + 1) * p;
            float t = ((float)Perm[i]) * p;
            float b = ((float)Perm[i]+1) * p;
            
            pRenderTarget->FillRectangle(
                RectF(l*g_nWidth/s-pad,
                    t*g_nHeight/s-pad,
                    r*g_nWidth/s+pad,
                    b*g_nHeight/s+pad),
                pBrush);
        }

        pBrush->SetColor(ColorF(ColorF::Gray));

        pRenderTarget->DrawLine(Point2F(SliderBorder, SliderBorder),
            Point2F(g_nWidth/s - SliderBorder, SliderBorder),
            pBrush, 3.0f);
        pBrush->SetColor(ColorF(ColorF::Black));
        pRenderTarget->FillEllipse(Ellipse(Point2F(SliderBorder + (g_nWidth/s - 2 * SliderBorder) * q, SliderBorder), SliderR, SliderR), pBrush);



        pBrush->Release();
        pRenderTarget->EndDraw();

        pRenderTarget->Release();

        break;
    }
    case WM_EXITSIZEMOVE:
    {
        RECT rect;
        GetClientRect(hWnd, &rect);

        g_nWidth = rect.right - rect.left;
        g_nHeight = rect.bottom - rect.top;

        break;
    }
    case WM_LBUTTONDOWN:
    {
        // xPos and yPos are valid here
        g_IsDown = true;

        // testing code
        g_nX = xPos/s;
        g_nY = yPos/s;

        if (g_nX > SliderBorder && g_nX < g_nWidth / s - SliderBorder &&
            g_nY > SliderBorder - SliderHeight / 2 && g_nY < SliderBorder + SliderHeight / 2)
        {
            isOnSlider = true;
            q = ((float)g_nX - SliderBorder) / (g_nWidth / s - SliderBorder * 2);
            Resample();
            Refresh(hWnd);
        }
        break;
    }
    case WM_MOUSEMOVE:
    {
        // xPos and yPos are valid here
        g_nX = xPos/s;
        g_nY = yPos/s;
        if (isOnSlider)
        {
            // testing code
            q = ((float)g_nX - SliderBorder) / (g_nWidth / s - SliderBorder * 2);
            Resample();
            Refresh(hWnd);
        }
        break;
    }
    case WM_LBUTTONUP:
    {
        // xPos and yPos are valid here
        g_IsDown = false;
        isOnSlider = false;
        g_nX = xPos/s;
        g_nY = yPos/s;
        break;
    }
    case WM_KEYUP:
    {
        switch (wParam)
        {
        case VK_RETURN:
            Refresh(hWnd);
            break;
        case VK_SPACE:
            Resample();
            Refresh(hWnd);
            break;
        }
        break;
    }
    case WM_DESTROY:
    {
        PostQuitMessage(0);
        break;
    }
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEX wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_APPLICATION));

    return RegisterClassEx(&wcex);
}
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // Store instance handle in our global variable

    RECT rc = { 0, 0, g_nWidth, g_nHeight };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, FALSE);

    g_hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, rc.right - rc.left, rc.bottom - rc.top, NULL, NULL, hInstance, NULL);

    if (!g_hWnd)
        return FALSE;

    ShowWindow(g_hWnd, nCmdShow);
    UpdateWindow(g_hWnd);

    return TRUE;
}

#include <shellscalingapi.h>

#pragma comment (lib, "Shcore.lib")

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    SetProcessDpiAwareness(PROCESS_PER_MONITOR_DPI_AWARE);


    s = GetDpiForSystem() / 96.0f;
    g_nHeight = 700 * s;
    g_nWidth = 700 * s;


    if (FAILED(InitD2D()))
    {
        MessageBox(NULL, Text("Failed creating D2D devices!"), Text("ERROR"), 0);
        return FALSE;
    }

    // Initialize global strings
    szTitle = Text("Title");
    szWindowClass = Text("Animation2D");
    MyRegisterClass(hInstance);

    // Perform application initialization:
    if (!InitInstance(hInstance, nCmdShow))
    {
        MessageBox(NULL, Text("Failed creating window!"), Text("ERROR"), 0);
        return FALSE;
    }


    InitPerm();

    MSG msg;
    ZeroMemory(&msg, sizeof(MSG));

    // Main message loop:
    while (msg.message != WM_QUIT)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    CleanupPerm();

    CleanUpD2D();
    _CrtDumpMemoryLeaks();

    return (int)msg.wParam;
}