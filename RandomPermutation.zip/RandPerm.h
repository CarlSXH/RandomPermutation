
#ifndef __RAND_PERM_H__
#define __RAND_PERM_H__


#include "MyRandom.h"



struct PermData {
    // number of blocks in a row
    unsigned int k;
    
    // number of blocks in a column
    unsigned int l;

    // the widths of each block
    // X[0], ..., X[k-1]
    unsigned int *X;
    
    // the heights of each block
    // Y[0], ..., Y[l-1]
    unsigned int *Y;
    
    // the restriction matrix
    // I[u*l + v] for 0 <= u < l
    //                0 <= v < k
    bool *I;

    bool Get(unsigned int u, unsigned int v);
    void Set(unsigned int u, unsigned int v, bool b);
};

struct MonoPermData
{
    // number of blocks in a row
    unsigned int dim;

    // the widths of each block
    // X[0], ..., X[k-1]
    unsigned int *X;

    // the heights of each block
    // Y[0], ..., Y[l-1]
    unsigned int *Y;
};


void MonotoneSampling(MonoPermData d, unsigned int N, float q, unsigned int *perm, RandDevice device);



#endif //__RAND_PERM_H__