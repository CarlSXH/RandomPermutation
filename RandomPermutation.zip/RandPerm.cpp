

#include "RandPerm.h"
#include <random>



bool PermData::Get(unsigned int u, unsigned int v)
{
    return I[u*l+v];
}


void PermData::Set(unsigned int u, unsigned int v, bool b)
{
    I[u * l + v] = b;
}



void MonotoneSampling(MonoPermData d, unsigned int N, float q, unsigned int *perm, RandDevice device)
{
    unsigned int index = 0;

    // number of rows left that are able to be sampled.
    unsigned int curRowLeft = 0;
    for (int i = 0; i < d.dim; i++)
    {
        curRowLeft += d.Y[i] * N;
        for (int j = 0; j < d.X[i]*N; j++)
        {
            perm[index++] = TrunGeom(device, q, curRowLeft);
            curRowLeft--;
        }
    }

    bool *used = new bool[index];
    for (int i = 0; i < index; i++)
        used[i] = false;

    for (int i = 0; i < index; i++)
    {
        int curIndex = 0;
        while (perm[i] > 1 || used[curIndex])
        {
            if (perm[i] > 1 && !used[curIndex])
                perm[i]--;
            curIndex++;
        }
        perm[i] = curIndex;
        used[curIndex] = true;
    }
}